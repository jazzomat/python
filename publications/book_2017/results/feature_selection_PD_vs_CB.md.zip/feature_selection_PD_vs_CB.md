Paul Desmond vs. Chet Baker |  (N = 18 vs. 15)
Rank |  Feature |  Mean (class) |  Mean (others) |  Significance (t-test) |  Cohen's D
1 |  mean_length_chromatic_ascending |  3.850000 |  2.002000 |  ** |  1.186310
7 |  int_std |  3.548889 |  2.709333 |  *** |  1.686036
19 |  mean_length_chromatic_sequences |  3.752778 |  2.193333 |  ** |  1.150731
